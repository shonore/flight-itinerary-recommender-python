import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='shonore99',
    application_name='flight-recommender',
    app_uid='BLxqJnS86Pk829NyzR',
    org_uid='3558ab7e-69f6-4d45-9efc-901d8e5af483',
    deployment_uid='d3331745-58d6-4d17-a60c-0e20742f3553',
    service_name='flight-recommender-api',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='6.2.2',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'flight-recommender-api-dev-recommend', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('recommender.getItineraries')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
